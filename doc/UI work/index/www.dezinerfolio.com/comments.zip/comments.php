<?php if ( !empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) : ?>

<p>
  <?php _e('Enter your password to view comments.'); ?>
</p>
<?php return; endif; ?>
<h2 id="comments" class="h2comment">
  <?php comments_number(__('No Comments'), __('1 Comment'), __('% Comments')); ?>
</h2>
<?php if ( comments_open() ) : ?>
<a class="makecomment" href="#postcomment" title="<?php _e("Leave a comment"); ?>">Make A Comment</a>
<?php endif; ?>
<div class="clear"></div>
<?php if ( $comments ) : ?>
<ul class="commentlist">
  <?php foreach ($comments as $comment) : ?>
  <li class="<?php echo $oddcomment; ?>" id="comment-<?php comment_ID() ?>">
    <?php



if (function_exists('gravatar')) {
if ('' != get_comment_author_url()) {
echo "<a href='$comment->comment_author_url' title='Visit $comment->comment_author'>";
} else {
echo "<a href='http://www.gravatar.com' title='Create your own gravatar at gravatar.com!'>";
}
echo "<img src='";
if ('' == $comment->comment_type) {
echo gravatar($comment->comment_author_email);
} elseif ( ('trackback' == $comment->comment_type) || ('pingback' == $comment->comment_type) ) {
echo gravatar($comment->comment_author_url);
}
echo "' alt='a gravatar' class='gravatar' /></a>";
}
?>
    <cite>
    <?php comment_author_link() ?>
    </cite> Said:
    <?php if ($comment->comment_approved == '0') : ?>
    <em>Your comment is awaiting moderation.</em>
    <?php endif; ?>
    <br />
    <small class="commentmetadata"><a href="#comment-<?php comment_ID() ?>" title="">
    <?php 

comment_date('F jS, Y') ?>
    at
    <?php comment_time() ?>
    </a>
    <?php edit_comment_link(' - edit','',''); ?>
    </small>
    <?php comment_text() ?>
  </li>
  <?php /* Changes every other comment to a different class */	
		if ('alt' == $oddcomment) $oddcomment = '';
		else $oddcomment = 'alt';
	?>
  <?php endforeach; /* end for each comment */ ?>
</ul>
<?php else : // If there are no comments yet ?>
<p>
  <?php _e('No comments yet.'); ?>
</p>
<?php endif; ?>
<p>
  <?php comments_rss_link(__('Comments RSS Feed')); ?>
  &nbsp;&nbsp;
  <?php if ( pings_open() ) : ?>
  <a href="<?php trackback_url() ?>" rel="trackback">
  <?php _e('TrackBack URL'); ?>
  </a>
  <?php endif; ?>
</p>
<?php if ( comments_open() ) : ?>
<h2 id="postcomment">
  <?php _e('Leave a comment'); ?>
</h2>
<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>You must be <a href="../Copy of red/<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">logged in</a> to post a comment.</p>
<?php
if (function_exists(show_authimage))
{
?>
<input type="text" name="code" id="code" value="" size="22" />
<?php
echo show_authimage();
}
?>
</p>
<?php else : ?>
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
  <?php if ( $user_ID ) : ?>
  <p>Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php _e('Log out of this account') ?>">Logout &raquo;</a></p>
  <?php
if (function_exists(show_authimage))
{
?>
  <input type="text" name="code" id="code" value="" size="22" />
  <?php
echo show_authimage();
 }
?>
  <?php else : ?>
  <p>
    <input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="40" tabindex="1" />
    <label for="author"><small>Name
    <?php if ($req) _e('(required)'); ?>
    </small></label>
  </p>
  <p>
    <input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="40" tabindex="2" />
    <label for="email"><small>Mail (will not be published)
    <?php if ($req) _e('(required)'); ?>
    </small></label>
  </p>
  <p>
    <input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="40" tabindex="3" />
    <label for="url"><small>Website</small></label>
  </p>
  <p>
    <!-- The code!!!!-->
    <?php
if (function_exists(show_authimage))
{
?>
    <input type="text" name="code" id="code" value="" tabindex="4" size="40" style="float:left" />
    <?php
 echo show_authimage();
}
?>
  </p>
  <?php endif; ?>
  <p>
    <textarea name="comment" id="comment" rows="10" tabindex="5" cols="10"></textarea>
  </p>
  <p>
    <input type="checkbox" name="subscribe" tabindex="6" id="subscribe" value="subscribe" />
    <label for="subscribe">Subscribe to comments</label>
  </p>
  <p>
    <input name="submit" type="submit" id="submit" tabindex="7" value="Submit Comment" />
    <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
  </p>
  <?php do_action('comment_form', $post->ID); ?>
</form>
<?php endif; // If registration required and not logged in ?>
<?php else : // Comments are closed ?>
<p>
  <?php _e('Sorry, the comment form is closed at this time.'); ?>
</p>
<?php endif; ?>
